// 用户角色
export type UserRole = 'customer' | 'chef';

// 菜品分类
export type Category = 'all' | 'hot' | 'cold' | 'soup' | 'staple' | 'drink' | 'dessert';

export interface CategoryInfo {
  id: Category;
  name: string;
  icon: string;
}

// 口味选项
export type Taste = 'none' | 'mild' | 'medium' | 'spicy';

export interface TasteOption {
  id: Taste;
  name: string;
}

// 菜品
export interface Dish {
  id: string;
  name: string;
  price: number;
  image: string;
  category: Category;
  ingredients: string[];
  tasteOptions: Taste[];
  description?: string;
  isAvailable: boolean;
  createdAt: number;
}

// 购物车项
export interface CartItem {
  dishId: string;
  dish: Dish;
  quantity: number;
  taste: Taste;
  remark: string;
}

// 订单状态
export type OrderStatus = 'pending' | 'confirmed' | 'completed' | 'cancelled';

// 订单项
export interface OrderItem {
  dishId: string;
  dishName: string;
  price: number;
  quantity: number;
  taste: Taste;
  remark: string;
}

// 订单
export interface Order {
  id: string;
  items: OrderItem[];
  totalAmount: number;
  status: OrderStatus;
  customerName: string;
  createdAt: number;
  completedAt?: number;
}

// 公告
export interface Announcement {
  id: string;
  content: string;
  createdAt: number;
  updatedAt: number;
  isActive: boolean;
}

// 用户
export interface User {
  id: string;
  name: string;
  role: UserRole;
  avatar?: string;
  createdAt: number;
}

// 统计数据
export interface Statistics {
  totalOrders: number;
  totalAmount: number;
  totalDishes: number;
  averageOrderValue: number;
}

// 菜品销量排行
export interface DishRanking {
  dishId: string;
  dishName: string;
  quantity: number;
  totalAmount: number;
}

// 时间筛选
export type TimeFilter = 'today' | 'week' | 'month' | 'all';

// 应用状态
export interface AppState {
  currentUser: User | null;
  cart: CartItem[];
  orders: Order[];
  dishes: Dish[];
  announcements: Announcement[];
  categories: CategoryInfo[];
}
