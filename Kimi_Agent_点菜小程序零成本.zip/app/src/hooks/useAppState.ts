import { useCallback, useMemo } from 'react';
import { useLocalStorage } from './useStorage';
import type {
  User,
  UserRole,
  CartItem,
  Order,
  Dish,
  Announcement,
  CategoryInfo,
  Taste,
  OrderItem,
  DishRanking,
  TimeFilter,
} from '@/types';

const DEFAULT_CATEGORIES: CategoryInfo[] = [
  { id: 'all', name: '全部', icon: '🍽️' },
  { id: 'hot', name: '热菜', icon: '🍲' },
  { id: 'cold', name: '凉菜', icon: '🥗' },
  { id: 'soup', name: '汤羹', icon: '🥣' },
  { id: 'staple', name: '主食', icon: '🍚' },
  { id: 'drink', name: '饮品', icon: '🧃' },
  { id: 'dessert', name: '甜点', icon: '🍰' },
];

const DEFAULT_DISHES: Dish[] = [
  {
    id: '1',
    name: '红烧肉',
    price: 38,
    image: '🍖',
    category: 'hot',
    ingredients: ['五花肉', '冰糖', '酱油'],
    tasteOptions: ['none', 'mild', 'medium'],
    description: '肥而不腻，入口即化',
    isAvailable: true,
    createdAt: Date.now(),
  },
  {
    id: '2',
    name: '麻婆豆腐',
    price: 22,
    image: '🥘',
    category: 'hot',
    ingredients: ['豆腐', '肉末', '豆瓣酱'],
    tasteOptions: ['mild', 'medium', 'spicy'],
    description: '麻辣鲜香，下饭神器',
    isAvailable: true,
    createdAt: Date.now(),
  },
  {
    id: '3',
    name: '凉拌黄瓜',
    price: 12,
    image: '🥒',
    category: 'cold',
    ingredients: ['黄瓜', '蒜', '醋'],
    tasteOptions: ['none', 'mild'],
    description: '清爽解腻，开胃小菜',
    isAvailable: true,
    createdAt: Date.now(),
  },
  {
    id: '4',
    name: '西红柿蛋汤',
    price: 15,
    image: '🍅',
    category: 'soup',
    ingredients: ['西红柿', '鸡蛋', '葱花'],
    tasteOptions: ['none'],
    description: '家常美味，营养丰富',
    isAvailable: true,
    createdAt: Date.now(),
  },
  {
    id: '5',
    name: '蛋炒饭',
    price: 16,
    image: '🍚',
    category: 'staple',
    ingredients: ['米饭', '鸡蛋', '葱花'],
    tasteOptions: ['none', 'mild'],
    description: '粒粒分明，香气四溢',
    isAvailable: true,
    createdAt: Date.now(),
  },
  {
    id: '6',
    name: '珍珠奶茶',
    price: 15,
    image: '🧋',
    category: 'drink',
    ingredients: ['红茶', '牛奶', '珍珠'],
    tasteOptions: ['none'],
    description: '香甜可口，Q弹珍珠',
    isAvailable: true,
    createdAt: Date.now(),
  },
  {
    id: '7',
    name: '草莓蛋糕',
    price: 28,
    image: '🍰',
    category: 'dessert',
    ingredients: ['面粉', '奶油', '草莓'],
    tasteOptions: ['none'],
    description: '甜蜜滋味，幸福满满',
    isAvailable: true,
    createdAt: Date.now(),
  },
  {
    id: '8',
    name: '糖醋里脊',
    price: 32,
    image: '🥩',
    category: 'hot',
    ingredients: ['里脊肉', '糖', '醋'],
    tasteOptions: ['none'],
    description: '酸甜可口，外酥里嫩',
    isAvailable: true,
    createdAt: Date.now(),
  },
];

export function useAppState() {
  const [currentUser, setCurrentUser] = useLocalStorage<User | null>('kc-user', null);
  const [cart, setCart] = useLocalStorage<CartItem[]>('kc-cart', []);
  const [orders, setOrders] = useLocalStorage<Order[]>('kc-orders', []);
  const [dishes, setDishes] = useLocalStorage<Dish[]>('kc-dishes', DEFAULT_DISHES);
  const [announcements, setAnnouncements] = useLocalStorage<Announcement[]>('kc-announcements', []);
  const [categories] = useLocalStorage<CategoryInfo[]>('kc-categories', DEFAULT_CATEGORIES);

  // 用户相关
  const login = useCallback((name: string, role: UserRole) => {
    const user: User = {
      id: Date.now().toString(),
      name,
      role,
      createdAt: Date.now(),
    };
    setCurrentUser(user);
    return user;
  }, [setCurrentUser]);

  const logout = useCallback(() => {
    setCurrentUser(null);
  }, [setCurrentUser]);

  const switchRole = useCallback(() => {
    if (currentUser) {
      const newRole = currentUser.role === 'chef' ? 'customer' : 'chef';
      setCurrentUser({ ...currentUser, role: newRole });
    }
  }, [currentUser, setCurrentUser]);

  // 购物车相关
  const addToCart = useCallback((item: CartItem) => {
    setCart(prev => {
      const existingIndex = prev.findIndex(
        i => i.dishId === item.dishId && i.taste === item.taste && i.remark === item.remark
      );
      if (existingIndex >= 0) {
        const newCart = [...prev];
        newCart[existingIndex].quantity += item.quantity;
        return newCart;
      }
      return [...prev, item];
    });
  }, [setCart]);

  const removeFromCart = useCallback((dishId: string, taste: Taste, remark: string) => {
    setCart(prev => prev.filter(i => !(i.dishId === dishId && i.taste === taste && i.remark === remark)));
  }, [setCart]);

  const updateCartQuantity = useCallback((dishId: string, taste: Taste, remark: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(dishId, taste, remark);
      return;
    }
    setCart(prev =>
      prev.map(i =>
        i.dishId === dishId && i.taste === taste && i.remark === remark
          ? { ...i, quantity }
          : i
      )
    );
  }, [setCart, removeFromCart]);

  const clearCart = useCallback(() => {
    setCart([]);
  }, [setCart]);

  const cartTotal = useMemo(() => {
    return cart.reduce((sum, item) => sum + item.dish.price * item.quantity, 0);
  }, [cart]);

  const cartCount = useMemo(() => {
    return cart.reduce((sum, item) => sum + item.quantity, 0);
  }, [cart]);

  // 订单相关
  const createOrder = useCallback((customerName: string) => {
    if (cart.length === 0) return null;
    
    const orderItems: OrderItem[] = cart.map(item => ({
      dishId: item.dishId,
      dishName: item.dish.name,
      price: item.dish.price,
      quantity: item.quantity,
      taste: item.taste,
      remark: item.remark,
    }));

    const order: Order = {
      id: `ORD${Date.now()}`,
      items: orderItems,
      totalAmount: cartTotal,
      status: 'pending',
      customerName,
      createdAt: Date.now(),
    };

    setOrders(prev => [order, ...prev]);
    clearCart();
    return order;
  }, [cart, cartTotal, setOrders, clearCart]);

  const updateOrderStatus = useCallback((orderId: string, status: Order['status']) => {
    setOrders(prev =>
      prev.map(o =>
        o.id === orderId
          ? { ...o, status, completedAt: status === 'completed' ? Date.now() : o.completedAt }
          : o
      )
    );
  }, [setOrders]);

  const deleteOrder = useCallback((orderId: string) => {
    setOrders(prev => prev.filter(o => o.id !== orderId));
  }, [setOrders]);

  // 菜品相关
  const addDish = useCallback((dish: Omit<Dish, 'id' | 'createdAt'>) => {
    const newDish: Dish = {
      ...dish,
      id: Date.now().toString(),
      createdAt: Date.now(),
    };
    setDishes(prev => [newDish, ...prev]);
    return newDish;
  }, [setDishes]);

  const updateDish = useCallback((id: string, updates: Partial<Dish>) => {
    setDishes(prev =>
      prev.map(d => (d.id === id ? { ...d, ...updates } : d))
    );
  }, [setDishes]);

  const deleteDish = useCallback((id: string) => {
    setDishes(prev => prev.filter(d => d.id !== id));
  }, [setDishes]);

  // 公告相关
  const addAnnouncement = useCallback((content: string) => {
    const announcement: Announcement = {
      id: Date.now().toString(),
      content,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      isActive: true,
    };
    setAnnouncements(prev => [announcement, ...prev]);
    return announcement;
  }, [setAnnouncements]);

  const updateAnnouncement = useCallback((id: string, content: string) => {
    setAnnouncements(prev =>
      prev.map(a =>
        a.id === id ? { ...a, content, updatedAt: Date.now() } : a
      )
    );
  }, [setAnnouncements]);

  const deleteAnnouncement = useCallback((id: string) => {
    setAnnouncements(prev => prev.filter(a => a.id !== id));
  }, [setAnnouncements]);

  const activeAnnouncement = useMemo(() => {
    return announcements.find(a => a.isActive);
  }, [announcements]);

  // 统计相关
  const getStatistics = useCallback((filter: TimeFilter = 'all') => {
    const now = Date.now();
    let filteredOrders = orders;

    if (filter === 'today') {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      filteredOrders = orders.filter(o => o.createdAt >= today.getTime());
    } else if (filter === 'week') {
      const weekAgo = now - 7 * 24 * 60 * 60 * 1000;
      filteredOrders = orders.filter(o => o.createdAt >= weekAgo);
    } else if (filter === 'month') {
      const monthAgo = now - 30 * 24 * 60 * 60 * 1000;
      filteredOrders = orders.filter(o => o.createdAt >= monthAgo);
    }

    const totalOrders = filteredOrders.length;
    const totalAmount = filteredOrders.reduce((sum, o) => sum + o.totalAmount, 0);
    const totalDishes = filteredOrders.reduce((sum, o) => sum + o.items.reduce((s, i) => s + i.quantity, 0), 0);
    const averageOrderValue = totalOrders > 0 ? totalAmount / totalOrders : 0;

    return {
      totalOrders,
      totalAmount,
      totalDishes,
      averageOrderValue,
    };
  }, [orders]);

  const getDishRanking = useCallback((filter: TimeFilter = 'all'): DishRanking[] => {
    const now = Date.now();
    let filteredOrders = orders;

    if (filter === 'today') {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      filteredOrders = orders.filter(o => o.createdAt >= today.getTime());
    } else if (filter === 'week') {
      const weekAgo = now - 7 * 24 * 60 * 60 * 1000;
      filteredOrders = orders.filter(o => o.createdAt >= weekAgo);
    } else if (filter === 'month') {
      const monthAgo = now - 30 * 24 * 60 * 60 * 1000;
      filteredOrders = orders.filter(o => o.createdAt >= monthAgo);
    }

    const dishMap = new Map<string, DishRanking>();

    filteredOrders.forEach(order => {
      order.items.forEach(item => {
        const existing = dishMap.get(item.dishId);
        if (existing) {
          existing.quantity += item.quantity;
          existing.totalAmount += item.price * item.quantity;
        } else {
          dishMap.set(item.dishId, {
            dishId: item.dishId,
            dishName: item.dishName,
            quantity: item.quantity,
            totalAmount: item.price * item.quantity,
          });
        }
      });
    });

    return Array.from(dishMap.values())
      .sort((a, b) => b.quantity - a.quantity)
      .slice(0, 10);
  }, [orders]);

  // 导出订单
  const exportOrders = useCallback((filter: TimeFilter = 'all') => {
    const now = Date.now();
    let filteredOrders = orders;

    if (filter === 'today') {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      filteredOrders = orders.filter(o => o.createdAt >= today.getTime());
    } else if (filter === 'week') {
      const weekAgo = now - 7 * 24 * 60 * 60 * 1000;
      filteredOrders = orders.filter(o => o.createdAt >= weekAgo);
    } else if (filter === 'month') {
      const monthAgo = now - 30 * 24 * 60 * 60 * 1000;
      filteredOrders = orders.filter(o => o.createdAt >= monthAgo);
    }

    const csvContent = [
      ['订单号', '下单时间', '顾客', '菜品', '数量', '金额', '状态'].join(','),
      ...filteredOrders.map(o => [
        o.id,
        new Date(o.createdAt).toLocaleString('zh-CN'),
        o.customerName,
        o.items.map(i => i.dishName).join(';'),
        o.items.reduce((sum, i) => sum + i.quantity, 0),
        o.totalAmount,
        o.status === 'pending' ? '待处理' : o.status === 'confirmed' ? '已确认' : o.status === 'completed' ? '已完成' : '已取消',
      ].join(','))
    ].join('\n');

    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `订单记录_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  }, [orders]);

  // 个人统计
  const getPersonalStats = useCallback((userId: string) => {
    const userOrders = orders.filter(o => o.customerName === userId);
    const totalSpent = userOrders.reduce((sum, o) => sum + o.totalAmount, 0);
    const totalOrders = userOrders.length;
    
    // 厨师收入统计
    const chefIncome = orders
      .filter(o => o.status !== 'cancelled')
      .reduce((sum, o) => sum + o.totalAmount, 0);

    return {
      totalSpent,
      totalOrders,
      chefIncome,
    };
  }, [orders]);

  return {
    // 用户
    currentUser,
    login,
    logout,
    switchRole,
    
    // 购物车
    cart,
    addToCart,
    removeFromCart,
    updateCartQuantity,
    clearCart,
    cartTotal,
    cartCount,
    
    // 订单
    orders,
    createOrder,
    updateOrderStatus,
    deleteOrder,
    
    // 菜品
    dishes,
    categories,
    addDish,
    updateDish,
    deleteDish,
    
    // 公告
    announcements,
    activeAnnouncement,
    addAnnouncement,
    updateAnnouncement,
    deleteAnnouncement,
    
    // 统计
    getStatistics,
    getDishRanking,
    exportOrders,
    getPersonalStats,
  };
}
