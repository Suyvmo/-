import { useState, useMemo } from 'react';
import { Download, ChevronDown, ChevronUp, Calendar, User, Package, CheckCircle, Clock, XCircle, AlertCircle } from 'lucide-react';
import type { Order, TimeFilter, Taste } from '@/types';

interface OrdersPageProps {
  orders: Order[];
  isChef: boolean;
  onUpdateStatus: (orderId: string, status: Order['status']) => void;
  onExport: (filter: TimeFilter) => void;
}

const TIME_FILTERS = [
  { id: 'today' as TimeFilter, name: '今日' },
  { id: 'week' as TimeFilter, name: '本周' },
  { id: 'month' as TimeFilter, name: '本月' },
  { id: 'all' as TimeFilter, name: '全部' },
];

const STATUS_CONFIG: Record<Order['status'], { label: string; color: string; icon: typeof Clock }> = {
  pending: { label: '待处理', color: 'bg-yellow-100 text-yellow-700', icon: Clock },
  confirmed: { label: '已确认', color: 'bg-blue-100 text-blue-700', icon: AlertCircle },
  completed: { label: '已完成', color: 'bg-green-100 text-green-700', icon: CheckCircle },
  cancelled: { label: '已取消', color: 'bg-gray-100 text-gray-700', icon: XCircle },
};

const TASTE_NAMES: Record<Taste, string> = {
  none: '不辣',
  mild: '微辣',
  medium: '中辣',
  spicy: '特辣',
};

export function OrdersPage({ orders, isChef, onUpdateStatus, onExport }: OrdersPageProps) {
  const [activeFilter, setActiveFilter] = useState<TimeFilter>('all');
  const [expandedOrder, setExpandedOrder] = useState<string | null>(null);

  const filteredOrders = useMemo(() => {
    const now = Date.now();
    let result = [...orders];

    if (activeFilter === 'today') {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      result = result.filter(o => o.createdAt >= today.getTime());
    } else if (activeFilter === 'week') {
      const weekAgo = now - 7 * 24 * 60 * 60 * 1000;
      result = result.filter(o => o.createdAt >= weekAgo);
    } else if (activeFilter === 'month') {
      const monthAgo = now - 30 * 24 * 60 * 60 * 1000;
      result = result.filter(o => o.createdAt >= monthAgo);
    }

    return result.sort((a, b) => b.createdAt - a.createdAt);
  }, [orders, activeFilter]);

  const toggleExpand = (orderId: string) => {
    setExpandedOrder(expandedOrder === orderId ? null : orderId);
  };

  const handleExport = () => {
    onExport(activeFilter);
  };

  return (
    <div className="content-area pb-24">
      {/* 头部操作栏 */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex gap-2 flex-1">
          {TIME_FILTERS.map((filter) => (
            <button
              key={filter.id}
              onClick={() => setActiveFilter(filter.id)}
              className={`px-3 py-2 rounded-xl text-sm font-medium transition-all ${
                activeFilter === filter.id
                  ? 'bg-gradient-to-r from-[var(--sakura-pink)] to-[var(--sakura-light)] text-white'
                  : 'bg-white text-[var(--warm-brown)] hover:bg-gray-50'
              }`}
            >
              {filter.name}
            </button>
          ))}
        </div>
        <button
          onClick={handleExport}
          className="p-2.5 rounded-xl bg-white hover:bg-gray-50 transition-colors ml-2"
          title="导出订单"
        >
          <Download className="w-5 h-5 text-[var(--sakura-pink)]" />
        </button>
      </div>

      {/* 订单列表 */}
      {filteredOrders.length > 0 ? (
        <div className="space-y-3">
          {filteredOrders.map((order, index) => {
            const status = STATUS_CONFIG[order.status];
            const StatusIcon = status.icon;
            const isExpanded = expandedOrder === order.id;

            return (
              <div
                key={order.id}
                className="card-sakura overflow-hidden animate-fade-in-up"
                style={{ animationDelay: `${index * 80}ms` }}
              >
                {/* 订单头部 */}
                <div 
                  className="p-4 cursor-pointer"
                  onClick={() => toggleExpand(order.id)}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-[var(--warm-brown)]">
                        {order.id.slice(-6)}
                      </span>
                      <span className={`px-2 py-0.5 rounded-lg text-xs font-medium flex items-center gap-1 ${status.color}`}>
                        <StatusIcon className="w-3 h-3" />
                        {status.label}
                      </span>
                    </div>
                    <span className="text-lg font-bold text-[var(--sakura-pink)]">
                      ¥{order.totalAmount}
                    </span>
                  </div>

                  <div className="flex items-center gap-4 text-xs text-[var(--soft-brown)]">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      {new Date(order.createdAt).toLocaleString('zh-CN', {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                    <span className="flex items-center gap-1">
                      <User className="w-3.5 h-3.5" />
                      {order.customerName}
                    </span>
                    <span className="flex items-center gap-1">
                      <Package className="w-3.5 h-3.5" />
                      {order.items.reduce((sum, i) => sum + i.quantity, 0)}件
                    </span>
                  </div>
                </div>

                {/* 展开的详情 */}
                {isExpanded && (
                  <div className="px-4 pb-4 border-t border-gray-100 pt-3 animate-fade-in-up">
                    <div className="space-y-2 mb-4">
                      {order.items.map((item, i) => (
                        <div key={i} className="flex items-center justify-between text-sm">
                          <div className="flex items-center gap-2">
                            <span className="text-[var(--warm-brown)]">{item.dishName}</span>
                            <span className="text-xs text-gray-400">
                              {TASTE_NAMES[item.taste]}
                              {item.remark && ` | ${item.remark}`}
                            </span>
                          </div>
                          <span className="text-gray-600">
                            x{item.quantity} ¥{item.price * item.quantity}
                          </span>
                        </div>
                      ))}
                    </div>

                    {/* 厨师操作按钮 */}
                    {isChef && order.status !== 'completed' && order.status !== 'cancelled' && (
                      <div className="flex gap-2">
                        {order.status === 'pending' && (
                          <button
                            onClick={() => onUpdateStatus(order.id, 'confirmed')}
                            className="flex-1 py-2 rounded-xl bg-blue-500 text-white text-sm font-medium hover:bg-blue-600 transition-colors"
                          >
                            确认订单
                          </button>
                        )}
                        {(order.status === 'pending' || order.status === 'confirmed') && (
                          <button
                            onClick={() => onUpdateStatus(order.id, 'completed')}
                            className="flex-1 py-2 rounded-xl bg-green-500 text-white text-sm font-medium hover:bg-green-600 transition-colors"
                          >
                            完成订单
                          </button>
                        )}
                        <button
                          onClick={() => onUpdateStatus(order.id, 'cancelled')}
                          className="px-4 py-2 rounded-xl bg-gray-200 text-gray-600 text-sm font-medium hover:bg-gray-300 transition-colors"
                        >
                          取消
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {/* 展开/收起指示器 */}
                <div className="flex justify-center py-1 border-t border-gray-50">
                  {isExpanded ? (
                    <ChevronUp className="w-4 h-4 text-gray-400" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-gray-400" />
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="empty-state">
          <span className="empty-state-icon">📋</span>
          <p className="empty-state-text">暂无订单记录</p>
        </div>
      )}
    </div>
  );
}
