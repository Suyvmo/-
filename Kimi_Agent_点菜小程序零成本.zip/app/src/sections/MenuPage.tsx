import { useState, useMemo } from 'react';
import { Plus, Search } from 'lucide-react';
import { DishCard } from '@/components/DishCard';
import { CartDrawer } from '@/components/CartDrawer';
import type { Dish, Category, CartItem, Taste } from '@/types';

interface MenuPageProps {
  dishes: Dish[];
  categories: { id: Category; name: string; icon: string }[];
  cart: CartItem[];
  cartTotal: number;
  isChef: boolean;
  currentUser: { name: string } | null;
  onAddToCart: (item: CartItem) => void;
  onUpdateCartQuantity: (dishId: string, taste: Taste, remark: string, quantity: number) => void;
  onRemoveFromCart: (dishId: string, taste: Taste, remark: string) => void;
  onCreateOrder: (customerName: string) => void;
  onEditDish: (dish: Dish) => void;
  onDeleteDish: (dishId: string) => void;
  onAddDish: () => void;
}

export function MenuPage({
  dishes,
  categories,
  cart,
  cartTotal,
  isChef,
  currentUser,
  onAddToCart,
  onUpdateCartQuantity,
  onRemoveFromCart,
  onCreateOrder,
  onEditDish,
  onDeleteDish,
  onAddDish,
}: MenuPageProps) {
  const [activeCategory, setActiveCategory] = useState<Category>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredDishes = useMemo(() => {
    let result = dishes;
    
    if (activeCategory !== 'all') {
      result = result.filter(d => d.category === activeCategory);
    }
    
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      result = result.filter(d => 
        d.name.toLowerCase().includes(query) ||
        d.ingredients.some(i => i.toLowerCase().includes(query))
      );
    }
    
    // 厨师看到所有菜品，食客只看到上架的
    if (!isChef) {
      result = result.filter(d => d.isAvailable);
    }
    
    return result;
  }, [dishes, activeCategory, searchQuery, isChef]);

  const handleAddToCart = (dish: Dish, taste: Taste, remark: string, quantity: number) => {
    onAddToCart({
      dishId: dish.id,
      dish,
      quantity,
      taste,
      remark,
    });
  };

  const handleSubmitOrder = () => {
    const customerName = currentUser?.name || '匿名用户';
    onCreateOrder(customerName);
  };

  return (
    <div className="content-area">
      {/* 搜索栏 */}
      <div className="relative mb-4">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="搜索菜品或原材料..."
          className="input-sakura pl-12 pr-4"
        />
      </div>

      {/* 分类标签 */}
      <div className="flex gap-2 overflow-x-auto pb-3 mb-2 scrollbar-hide">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all ${
              activeCategory === cat.id
                ? 'bg-gradient-to-r from-[var(--sakura-pink)] to-[var(--sakura-light)] text-white scale-105'
                : 'bg-white text-[var(--warm-brown)] hover:bg-gray-50'
            }`}
          >
            <span>{cat.icon}</span>
            <span>{cat.name}</span>
          </button>
        ))}
      </div>

      {/* 厨师添加按钮 */}
      {isChef && (
        <button
          onClick={onAddDish}
          className="w-full mb-4 py-3 rounded-2xl border-2 border-dashed border-[var(--sakura-pink)] text-[var(--sakura-pink)] flex items-center justify-center gap-2 hover:bg-[var(--sakura-lighter)] transition-colors"
        >
          <Plus className="w-5 h-5" />
          <span className="font-medium">添加新菜品</span>
        </button>
      )}

      {/* 菜品网格 */}
      {filteredDishes.length > 0 ? (
        <div className="grid grid-cols-2 gap-3 pb-32">
          {filteredDishes.map((dish, index) => (
            <DishCard
              key={dish.id}
              dish={dish}
              isChef={isChef}
              onAddToCart={handleAddToCart}
              onEdit={onEditDish}
              onDelete={onDeleteDish}
              index={index}
            />
          ))}
        </div>
      ) : (
        <div className="empty-state">
          <span className="empty-state-icon">🔍</span>
          <p className="empty-state-text">
            {searchQuery ? '没有找到相关菜品' : '该分类暂无菜品'}
          </p>
        </div>
      )}

      {/* 购物车 - 只有食客显示 */}
      {!isChef && (
        <CartDrawer
          cart={cart}
          total={cartTotal}
          onUpdateQuantity={onUpdateCartQuantity}
          onRemove={onRemoveFromCart}
          onSubmit={handleSubmitOrder}
          customerName={currentUser?.name || ''}
        />
      )}
    </div>
  );
}
