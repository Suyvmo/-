import { useState, useMemo } from 'react';
import { TrendingUp, DollarSign, ShoppingBag, Package, Trophy, Medal, Award } from 'lucide-react';
import type { DishRanking, TimeFilter } from '@/types';

interface StatsPageProps {
  getStatistics: (filter: TimeFilter) => {
    totalOrders: number;
    totalAmount: number;
    totalDishes: number;
    averageOrderValue: number;
  };
  getDishRanking: (filter: TimeFilter) => DishRanking[];
}

const TIME_FILTERS = [
  { id: 'today' as TimeFilter, name: '今日' },
  { id: 'week' as TimeFilter, name: '本周' },
  { id: 'month' as TimeFilter, name: '本月' },
  { id: 'all' as TimeFilter, name: '全部' },
];

const RANK_ICONS = [
  { icon: Trophy, color: 'text-yellow-500', bg: 'bg-yellow-100' },
  { icon: Medal, color: 'text-gray-400', bg: 'bg-gray-100' },
  { icon: Award, color: 'text-amber-600', bg: 'bg-amber-100' },
];

export function StatsPage({ getStatistics, getDishRanking }: StatsPageProps) {
  const [activeFilter, setActiveFilter] = useState<TimeFilter>('today');
  const [animatedStats, setAnimatedStats] = useState({
    totalOrders: 0,
    totalAmount: 0,
    totalDishes: 0,
    averageOrderValue: 0,
  });

  const stats = useMemo(() => {
    return getStatistics(activeFilter);
  }, [activeFilter, getStatistics]);

  const ranking = useMemo(() => {
    return getDishRanking(activeFilter);
  }, [activeFilter, getDishRanking]);

  // 数字动画效果
  useState(() => {
    const duration = 800;
    const steps = 30;
    const interval = duration / steps;
    
    let step = 0;
    const timer = setInterval(() => {
      step++;
      const progress = step / steps;
      const easeOut = 1 - Math.pow(1 - progress, 3);
      
      setAnimatedStats({
        totalOrders: Math.round(stats.totalOrders * easeOut),
        totalAmount: Math.round(stats.totalAmount * easeOut),
        totalDishes: Math.round(stats.totalDishes * easeOut),
        averageOrderValue: Math.round(stats.averageOrderValue * easeOut),
      });
      
      if (step >= steps) {
        clearInterval(timer);
        setAnimatedStats(stats);
      }
    }, interval);

    return () => clearInterval(timer);
  });

  const statCards = [
    { 
      label: '订单总数', 
      value: animatedStats.totalOrders, 
      icon: ShoppingBag, 
      color: 'from-pink-400 to-pink-500',
      suffix: '单'
    },
    { 
      label: '销售总额', 
      value: animatedStats.totalAmount, 
      icon: DollarSign, 
      color: 'from-rose-400 to-rose-500',
      suffix: '元',
      isMoney: true
    },
    { 
      label: '菜品销量', 
      value: animatedStats.totalDishes, 
      icon: Package, 
      color: 'from-purple-400 to-purple-500',
      suffix: '份'
    },
    { 
      label: '平均客单价', 
      value: animatedStats.averageOrderValue, 
      icon: TrendingUp, 
      color: 'from-orange-400 to-orange-500',
      suffix: '元',
      isMoney: true
    },
  ];

  return (
    <div className="content-area pb-24">
      {/* 时间筛选 */}
      <div className="flex gap-2 mb-6">
        {TIME_FILTERS.map((filter) => (
          <button
            key={filter.id}
            onClick={() => setActiveFilter(filter.id)}
            className={`flex-1 py-2.5 rounded-xl text-sm font-medium transition-all ${
              activeFilter === filter.id
                ? 'bg-gradient-to-r from-[var(--sakura-pink)] to-[var(--sakura-light)] text-white'
                : 'bg-white text-[var(--warm-brown)] hover:bg-gray-50'
            }`}
          >
            {filter.name}
          </button>
        ))}
      </div>

      {/* 统计卡片 */}
      <div className="grid grid-cols-2 gap-3 mb-6">
        {statCards.map((card, index) => {
          const Icon = card.icon;
          return (
            <div
              key={card.label}
              className="card-sakura p-4 animate-fade-in-up"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className={`w-10 h-10 rounded-xl bg-gradient-to-r ${card.color} flex items-center justify-center mb-3`}>
                <Icon className="w-5 h-5 text-white" />
              </div>
              <p className="text-xs text-[var(--soft-brown)] mb-1">{card.label}</p>
              <p className="text-xl font-bold text-[var(--warm-brown)]">
                {card.isMoney && '¥'}{card.value}
                <span className="text-sm font-normal text-[var(--soft-brown)] ml-0.5">{card.suffix}</span>
              </p>
            </div>
          );
        })}
      </div>

      {/* 菜品排行榜 */}
      <div className="card-sakura p-4">
        <div className="flex items-center gap-2 mb-4">
          <Trophy className="w-5 h-5 text-yellow-500" />
          <h3 className="font-bold text-[var(--warm-brown)]">菜品排行榜</h3>
        </div>

        {ranking.length > 0 ? (
          <div className="space-y-3">
            {ranking.map((item, index) => {
              const rankConfig = RANK_ICONS[index] || { icon: null, color: 'text-gray-400', bg: 'bg-gray-100' };
              const RankIcon = rankConfig.icon;
              
              return (
                <div
                  key={item.dishId}
                  className="flex items-center gap-3 p-3 rounded-xl bg-gray-50 animate-fade-in-up"
                  style={{ animationDelay: `${index * 50}ms` }}
                >
                  {/* 排名 */}
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${rankConfig.bg}`}>
                    {RankIcon ? (
                      <RankIcon className={`w-4 h-4 ${rankConfig.color}`} />
                    ) : (
                      <span className="text-sm font-bold text-gray-500">{index + 1}</span>
                    )}
                  </div>

                  {/* 菜品名 */}
                  <span className="flex-1 font-medium text-[var(--warm-brown)] text-sm">
                    {item.dishName}
                  </span>

                  {/* 销量 */}
                  <div className="text-right">
                    <span className="text-lg font-bold text-[var(--sakura-pink)]">{item.quantity}</span>
                    <span className="text-xs text-[var(--soft-brown)] ml-0.5">份</span>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="empty-state py-8">
            <span className="text-4xl mb-2">📊</span>
            <p className="text-sm text-[var(--soft-brown)]">暂无销售数据</p>
          </div>
        )}
      </div>
    </div>
  );
}
