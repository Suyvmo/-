import { useState } from 'react';
import { User, ChefHat, TrendingUp, ShoppingBag, DollarSign, LogOut, Edit2, Check, X } from 'lucide-react';
import type { User as UserType, UserRole } from '@/types';

interface ProfilePageProps {
  currentUser: UserType | null;
  stats: {
    totalSpent: number;
    totalOrders: number;
    chefIncome: number;
  };
  onLogin: (name: string, role: UserRole) => void;
  onLogout: () => void;
  onUpdateName: (name: string) => void;
}

export function ProfilePage({
  currentUser,
  stats,
  onLogin,
  onLogout,
  onUpdateName,
}: ProfilePageProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState(currentUser?.name || '');
  const [loginName, setLoginName] = useState('');
  const [loginRole, setLoginRole] = useState<UserRole>('customer');

  const handleSaveName = () => {
    if (editName.trim() && currentUser) {
      onUpdateName(editName.trim());
    }
    setIsEditing(false);
  };

  const handleLogin = () => {
    if (loginName.trim()) {
      onLogin(loginName.trim(), loginRole);
    }
  };

  // 未登录状态
  if (!currentUser) {
    return (
      <div className="content-area pb-24 flex flex-col items-center justify-center min-h-[60vh]">
        <div className="w-24 h-24 rounded-full bg-gradient-to-br from-[var(--sakura-pink)] to-[var(--sakura-light)] flex items-center justify-center mb-6 animate-bounce-soft">
          <User className="w-12 h-12 text-white" />
        </div>
        
        <h2 className="text-2xl font-bold text-[var(--warm-brown)] mb-2">欢迎使用小厨房</h2>
        <p className="text-[var(--soft-brown)] mb-8 text-center">请先登录以开始点菜</p>

        <div className="w-full max-w-xs space-y-4">
          <input
            type="text"
            value={loginName}
            onChange={(e) => setLoginName(e.target.value)}
            placeholder="请输入您的昵称"
            className="input-sakura text-center"
            onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
          />

          <div className="flex gap-3">
            <button
              onClick={() => setLoginRole('customer')}
              className={`flex-1 py-3 rounded-2xl text-sm font-medium transition-all flex items-center justify-center gap-2 ${
                loginRole === 'customer'
                  ? 'bg-gradient-to-r from-[var(--sakura-pink)] to-[var(--sakura-light)] text-white'
                  : 'bg-white text-[var(--warm-brown)]'
              }`}
            >
              <User className="w-4 h-4" />
              食客
            </button>
            <button
              onClick={() => setLoginRole('chef')}
              className={`flex-1 py-3 rounded-2xl text-sm font-medium transition-all flex items-center justify-center gap-2 ${
                loginRole === 'chef'
                  ? 'bg-gradient-to-r from-[var(--sakura-pink)] to-[var(--sakura-light)] text-white'
                  : 'bg-white text-[var(--warm-brown)]'
              }`}
            >
              <ChefHat className="w-4 h-4" />
              厨师
            </button>
          </div>

          <button
            onClick={handleLogin}
            disabled={!loginName.trim()}
            className="btn-sakura w-full py-4 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            开始体验
          </button>
        </div>
      </div>
    );
  }

  const isChef = currentUser.role === 'chef';

  return (
    <div className="content-area pb-24">
      {/* 用户信息卡片 */}
      <div className="card-sakura p-6 mb-4 text-center">
        <div className="w-20 h-20 rounded-full bg-gradient-to-br from-[var(--sakura-pink)] to-[var(--sakura-light)] flex items-center justify-center mx-auto mb-4 animate-bounce-soft">
          {isChef ? (
            <ChefHat className="w-10 h-10 text-white" />
          ) : (
            <User className="w-10 h-10 text-white" />
          )}
        </div>

        {isEditing ? (
          <div className="flex items-center justify-center gap-2 mb-2">
            <input
              type="text"
              value={editName}
              onChange={(e) => setEditName(e.target.value)}
              className="input-sakura text-center py-2 px-3 text-lg font-bold w-40"
              autoFocus
              onKeyDown={(e) => e.key === 'Enter' && handleSaveName()}
            />
            <button
              onClick={handleSaveName}
              className="p-2 rounded-full bg-green-100 text-green-600 hover:bg-green-200"
            >
              <Check className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                setIsEditing(false);
                setEditName(currentUser.name);
              }}
              className="p-2 rounded-full bg-gray-100 text-gray-600 hover:bg-gray-200"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <div className="flex items-center justify-center gap-2 mb-2">
            <h2 className="text-xl font-bold text-[var(--warm-brown)]">{currentUser.name}</h2>
            <button
              onClick={() => setIsEditing(true)}
              className="p-1.5 rounded-full hover:bg-gray-100 transition-colors"
            >
              <Edit2 className="w-4 h-4 text-gray-400" />
            </button>
          </div>
        )}

        <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium ${
          isChef 
            ? 'bg-orange-100 text-orange-600' 
            : 'bg-pink-100 text-pink-600'
        }`}>
          {isChef ? <ChefHat className="w-3 h-3" /> : <User className="w-3 h-3" />}
          {isChef ? '厨师' : '食客'}
        </span>
      </div>

      {/* 统计卡片 */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        {isChef ? (
          <>
            <div className="card-sakura p-4">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-green-400 to-green-500 flex items-center justify-center mb-3">
                <DollarSign className="w-5 h-5 text-white" />
              </div>
              <p className="text-xs text-[var(--soft-brown)] mb-1">累计收入</p>
              <p className="text-xl font-bold text-[var(--warm-brown)]">
                ¥{stats.chefIncome}
              </p>
            </div>
            <div className="card-sakura p-4">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-blue-400 to-blue-500 flex items-center justify-center mb-3">
                <ShoppingBag className="w-5 h-5 text-white" />
              </div>
              <p className="text-xs text-[var(--soft-brown)] mb-1">总订单数</p>
              <p className="text-xl font-bold text-[var(--warm-brown)]">
                {stats.totalOrders}
              </p>
            </div>
          </>
        ) : (
          <>
            <div className="card-sakura p-4">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-rose-400 to-rose-500 flex items-center justify-center mb-3">
                <TrendingUp className="w-5 h-5 text-white" />
              </div>
              <p className="text-xs text-[var(--soft-brown)] mb-1">累计支出</p>
              <p className="text-xl font-bold text-[var(--warm-brown)]">
                ¥{stats.totalSpent}
              </p>
            </div>
            <div className="card-sakura p-4">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-purple-400 to-purple-500 flex items-center justify-center mb-3">
                <ShoppingBag className="w-5 h-5 text-white" />
              </div>
              <p className="text-xs text-[var(--soft-brown)] mb-1">累计订单</p>
              <p className="text-xl font-bold text-[var(--warm-brown)]">
                {stats.totalOrders}
              </p>
            </div>
          </>
        )}
      </div>

      {/* 功能列表 */}
      <div className="card-sakura overflow-hidden">
        <div className="p-4 border-b border-gray-100 flex items-center justify-between hover:bg-gray-50 transition-colors cursor-pointer">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-pink-100 flex items-center justify-center">
              <ShoppingBag className="w-5 h-5 text-[var(--sakura-pink)]" />
            </div>
            <span className="font-medium text-[var(--warm-brown)]">我的订单</span>
          </div>
          <span className="text-sm text-gray-400">{stats.totalOrders}单</span>
        </div>

        <div className="p-4 flex items-center justify-between hover:bg-gray-50 transition-colors cursor-pointer">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-blue-500" />
            </div>
            <span className="font-medium text-[var(--warm-brown)]">消费统计</span>
          </div>
          <span className="text-sm text-gray-400">查看详情</span>
        </div>
      </div>

      {/* 退出登录 */}
      <button
        onClick={onLogout}
        className="w-full mt-4 py-4 rounded-2xl bg-gray-100 text-gray-600 font-medium flex items-center justify-center gap-2 hover:bg-gray-200 transition-colors"
      >
        <LogOut className="w-5 h-5" />
        退出登录
      </button>
    </div>
  );
}
