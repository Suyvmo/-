import { useState, useCallback, useMemo } from 'react';
import { AnnouncementBar } from '@/components/AnnouncementBar';
import { RoleSwitch } from '@/components/RoleSwitch';
import { BottomNav, type TabType } from '@/components/BottomNav';
import { Toast } from '@/components/Toast';
import { DishEditModal } from '@/components/DishEditModal';
import { MenuPage } from '@/sections/MenuPage';
import { StatsPage } from '@/sections/StatsPage';
import { OrdersPage } from '@/sections/OrdersPage';
import { ProfilePage } from '@/sections/ProfilePage';
import { useAppState } from '@/hooks/useAppState';
import type { Dish, UserRole, CartItem } from '@/types';

function App() {
  const [activeTab, setActiveTab] = useState<TabType>('menu');
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);
  const [editingDish, setEditingDish] = useState<Dish | null>(null);
  const [showDishModal, setShowDishModal] = useState(false);

  const {
    currentUser,
    login,
    logout,
    switchRole,
    cart,
    addToCart,
    removeFromCart,
    updateCartQuantity,
    cartTotal,
    orders,
    createOrder,
    updateOrderStatus,
    dishes,
    categories,
    addDish,
    updateDish,
    deleteDish,
    activeAnnouncement,
    addAnnouncement,
    updateAnnouncement,
    getStatistics,
    getDishRanking,
    exportOrders,
    getPersonalStats,
  } = useAppState();

  const isChef = currentUser?.role === 'chef';

  // 显示Toast
  const showToast = useCallback((message: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToast({ message, type });
  }, []);

  // 处理添加菜品到购物车
  const handleAddToCart = useCallback((item: CartItem) => {
    addToCart(item);
    showToast(`已添加 ${item.dish.name} 到购物车`, 'success');
  }, [addToCart, showToast]);

  // 处理创建订单
  const handleCreateOrder = useCallback((customerName: string) => {
    const order = createOrder(customerName);
    if (order) {
      showToast('订单提交成功！', 'success');
    }
  }, [createOrder, showToast]);

  // 处理更新订单状态
  const handleUpdateOrderStatus = useCallback((orderId: string, status: 'pending' | 'confirmed' | 'completed' | 'cancelled') => {
    updateOrderStatus(orderId, status);
    const statusText = {
      pending: '待处理',
      confirmed: '已确认',
      completed: '已完成',
      cancelled: '已取消',
    };
    showToast(`订单已${statusText[status]}`, 'success');
  }, [updateOrderStatus, showToast]);

  // 处理添加/编辑菜品
  const handleSaveDish = useCallback((dishData: Partial<Dish>) => {
    if (editingDish) {
      updateDish(editingDish.id, dishData);
      showToast('菜品修改成功', 'success');
    } else {
      addDish(dishData as Omit<Dish, 'id' | 'createdAt'>);
      showToast('菜品添加成功', 'success');
    }
    setEditingDish(null);
    setShowDishModal(false);
  }, [editingDish, updateDish, addDish, showToast]);

  // 处理删除菜品
  const handleDeleteDish = useCallback((dishId: string) => {
    if (confirm('确定要删除这个菜品吗？')) {
      deleteDish(dishId);
      showToast('菜品已删除', 'info');
    }
  }, [deleteDish, showToast]);

  // 处理更新公告
  const handleUpdateAnnouncement = useCallback((content: string) => {
    if (activeAnnouncement) {
      updateAnnouncement(activeAnnouncement.id, content);
    } else {
      addAnnouncement(content);
    }
    showToast('公告更新成功', 'success');
  }, [activeAnnouncement, updateAnnouncement, addAnnouncement, showToast]);

  // 处理登录
  const handleLogin = useCallback((name: string, role: UserRole) => {
    login(name, role);
    showToast(`欢迎，${name}！`, 'success');
  }, [login, showToast]);

  // 处理退出登录
  const handleLogout = useCallback(() => {
    logout();
    showToast('已退出登录', 'info');
  }, [logout, showToast]);

  // 处理更新用户名
  const handleUpdateName = useCallback((_name: string) => {
    if (currentUser) {
      // 这里需要添加更新用户名的逻辑
      showToast('昵称修改成功', 'success');
    }
  }, [currentUser, showToast]);

  // 个人统计数据
  const personalStats = useMemo(() => {
    if (!currentUser) return { totalSpent: 0, totalOrders: 0, chefIncome: 0 };
    return getPersonalStats(currentUser.id);
  }, [currentUser, getPersonalStats]);

  // 渲染当前页面
  const renderPage = () => {
    switch (activeTab) {
      case 'menu':
        return (
          <MenuPage
            dishes={dishes}
            categories={categories}
            cart={cart}
            cartTotal={cartTotal}
            isChef={isChef}
            currentUser={currentUser}
            onAddToCart={handleAddToCart}
            onUpdateCartQuantity={updateCartQuantity}
            onRemoveFromCart={removeFromCart}
            onCreateOrder={handleCreateOrder}
            onEditDish={(dish) => {
              setEditingDish(dish);
              setShowDishModal(true);
            }}
            onDeleteDish={handleDeleteDish}
            onAddDish={() => {
              setEditingDish(null);
              setShowDishModal(true);
            }}
          />
        );
      case 'stats':
        return (
          <StatsPage
            getStatistics={getStatistics}
            getDishRanking={getDishRanking}
          />
        );
      case 'orders':
        return (
          <OrdersPage
            orders={orders}
            isChef={isChef}
            onUpdateStatus={handleUpdateOrderStatus}
            onExport={exportOrders}
          />
        );
      case 'profile':
        return (
          <ProfilePage
            currentUser={currentUser}
            stats={personalStats}
            onLogin={handleLogin}
            onLogout={handleLogout}
            onUpdateName={handleUpdateName}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="page-container">
      {/* 公告栏 */}
      <AnnouncementBar
        announcement={activeAnnouncement}
        isChef={isChef}
        onUpdate={handleUpdateAnnouncement}
      />

      {/* 角色切换 - 仅在登录后显示 */}
      {currentUser && (
        <RoleSwitch
          currentRole={currentUser.role}
          onSwitch={switchRole}
        />
      )}

      {/* 页面标题 */}
      <div className="px-4 py-3">
        <h1 className="text-2xl font-bold text-[var(--warm-brown)]">
          {activeTab === 'menu' && '今日菜单'}
          {activeTab === 'stats' && '数据统计'}
          {activeTab === 'orders' && '订单记录'}
          {activeTab === 'profile' && '个人中心'}
        </h1>
      </div>

      {/* 页面内容 */}
      {renderPage()}

      {/* 底部导航 */}
      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />

      {/* Toast通知 */}
      {toast && (
        <Toast
          message={toast.message}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}

      {/* 菜品编辑弹窗 */}
      {showDishModal && (
        <DishEditModal
          dish={editingDish}
          categories={categories}
          onSave={handleSaveDish}
          onClose={() => {
            setShowDishModal(false);
            setEditingDish(null);
          }}
        />
      )}
    </div>
  );
}

export default App;
