import { UtensilsCrossed, BarChart3, ClipboardList, User } from 'lucide-react';

export type TabType = 'menu' | 'stats' | 'orders' | 'profile';

interface BottomNavProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
}

const NAV_ITEMS = [
  { id: 'menu' as TabType, label: '点菜', icon: UtensilsCrossed },
  { id: 'stats' as TabType, label: '统计', icon: BarChart3 },
  { id: 'orders' as TabType, label: '记录', icon: ClipboardList },
  { id: 'profile' as TabType, label: '我的', icon: User },
];

export function BottomNav({ activeTab, onTabChange }: BottomNavProps) {
  return (
    <nav className="nav-bottom">
      {NAV_ITEMS.map((item) => {
        const Icon = item.icon;
        const isActive = activeTab === item.id;
        
        return (
          <button
            key={item.id}
            onClick={() => onTabChange(item.id)}
            className={`nav-item ${isActive ? 'active' : ''}`}
          >
            <Icon className={`w-5 h-5 transition-transform ${isActive ? 'scale-110' : ''}`} />
            <span className="text-xs font-medium">{item.label}</span>
          </button>
        );
      })}
    </nav>
  );
}
