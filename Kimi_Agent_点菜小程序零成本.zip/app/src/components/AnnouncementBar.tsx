import { useState, useEffect } from 'react';
import { Megaphone, X, Edit2, Check } from 'lucide-react';
import type { Announcement } from '@/types';

interface AnnouncementBarProps {
  announcement?: Announcement;
  isChef: boolean;
  onUpdate?: (content: string) => void;
}

export function AnnouncementBar({ announcement, isChef, onUpdate }: AnnouncementBarProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editContent, setEditContent] = useState(announcement?.content || '');
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    setEditContent(announcement?.content || '');
  }, [announcement?.content]);

  const handleSave = () => {
    if (onUpdate && editContent.trim()) {
      onUpdate(editContent.trim());
    }
    setIsEditing(false);
  };

  if (!isVisible) return null;

  return (
    <div className="announcement-bar animate-slide-in-top relative">
      <div className="flex items-center justify-center gap-2">
        <Megaphone className="w-4 h-4 flex-shrink-0" />
        
        {isEditing ? (
          <div className="flex items-center gap-2 flex-1 max-w-xs">
            <input
              type="text"
              value={editContent}
              onChange={(e) => setEditContent(e.target.value)}
              placeholder="输入公告内容..."
              className="flex-1 px-3 py-1 rounded-xl text-sm text-gray-800 outline-none"
              autoFocus
              onKeyDown={(e) => e.key === 'Enter' && handleSave()}
            />
            <button
              onClick={handleSave}
              className="p-1 rounded-full bg-white/20 hover:bg-white/30 transition-colors"
            >
              <Check className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                setIsEditing(false);
                setEditContent(announcement?.content || '');
              }}
              className="p-1 rounded-full bg-white/20 hover:bg-white/30 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <>
            <span className="flex-1 truncate">
              {announcement?.content || '欢迎来到小厨房！今日推荐：红烧肉、麻婆豆腐'}
            </span>
            {isChef && (
              <button
                onClick={() => setIsEditing(true)}
                className="p-1 rounded-full bg-white/20 hover:bg-white/30 transition-colors ml-2"
              >
                <Edit2 className="w-3 h-3" />
              </button>
            )}
            <button
              onClick={() => setIsVisible(false)}
              className="p-1 rounded-full bg-white/20 hover:bg-white/30 transition-colors ml-2"
            >
              <X className="w-3 h-3" />
            </button>
          </>
        )}
      </div>
    </div>
  );
}
