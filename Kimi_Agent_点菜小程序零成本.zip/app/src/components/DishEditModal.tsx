import { useState, useEffect } from 'react';
import { X, Plus } from 'lucide-react';
import type { Dish, Category, Taste } from '@/types';

interface DishEditModalProps {
  dish?: Dish | null;
  categories: { id: Category; name: string }[];
  onSave: (dish: Partial<Dish>) => void;
  onClose: () => void;
}

const TASTE_OPTIONS: { id: Taste; name: string }[] = [
  { id: 'none', name: '不辣' },
  { id: 'mild', name: '微辣' },
  { id: 'medium', name: '中辣' },
  { id: 'spicy', name: '特辣' },
];

const EMOJI_OPTIONS = ['🍖', '🥘', '🥗', '🥣', '🍚', '🧃', '🍰', '🥩', '🍗', '🥟', '🍜', '🍲', '🥪', '🌮', '🍕', '🍔', '🍟', '🌭', '🥓', '🥚', '🥞', '🧇', '🥐', '🥨', '🥯', '🧀', '🥗', '🥙', '🧆', '🥫', '🍝', '🍠', '🥕', '🌽', '🥦', '🥬', '🥒', '🌶️', '🫑', '🥑', '🍆', '🍅', '🥝', '🥥', '🥭', '🍍', '🍋', '🍊', '🍉', '🍈', '🍇', '🍓', '🫐', '🍒', '🍑', '🍐', '🍏', '🍎'];

export function DishEditModal({ dish, categories, onSave, onClose }: DishEditModalProps) {
  const [formData, setFormData] = useState<Partial<Dish>>({
    name: '',
    price: 0,
    image: '🍖',
    category: 'hot',
    ingredients: [],
    tasteOptions: ['none'],
    description: '',
    isAvailable: true,
  });
  const [newIngredient, setNewIngredient] = useState('');
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);

  useEffect(() => {
    if (dish) {
      setFormData({ ...dish });
    }
  }, [dish]);

  const handleSave = () => {
    if (!formData.name || !formData.price) return;
    onSave(formData);
    onClose();
  };

  const addIngredient = () => {
    if (newIngredient.trim() && !formData.ingredients?.includes(newIngredient.trim())) {
      setFormData(prev => ({
        ...prev,
        ingredients: [...(prev.ingredients || []), newIngredient.trim()],
      }));
      setNewIngredient('');
    }
  };

  const removeIngredient = (ing: string) => {
    setFormData(prev => ({
      ...prev,
      ingredients: prev.ingredients?.filter(i => i !== ing) || [],
    }));
  };

  const toggleTaste = (taste: Taste) => {
    setFormData(prev => {
      const current = prev.tasteOptions || [];
      if (current.includes(taste)) {
        return { ...prev, tasteOptions: current.filter(t => t !== taste) };
      }
      return { ...prev, tasteOptions: [...current, taste] };
    });
  };

  return (
    <div 
      className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div 
        className="bg-white rounded-3xl w-full max-w-sm max-h-[90vh] overflow-auto animate-fade-in-up"
        onClick={(e) => e.stopPropagation()}
      >
        {/* 头部 */}
        <div className="sticky top-0 bg-white border-b border-gray-100 p-4 flex items-center justify-between">
          <h2 className="text-lg font-bold text-[var(--warm-brown)]">
            {dish ? '编辑菜品' : '添加菜品'}
          </h2>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-gray-100"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          {/* 菜品图标 */}
          <div>
            <label className="text-sm text-[var(--soft-brown)] mb-2 block">菜品图标</label>
            <div className="relative">
              <button
                onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                className="w-20 h-20 rounded-2xl bg-gradient-to-br from-pink-50 to-pink-100 flex items-center justify-center text-4xl hover:shadow-lg transition-shadow"
              >
                {formData.image}
              </button>
              
              {showEmojiPicker && (
                <div className="absolute top-full left-0 mt-2 p-3 bg-white rounded-2xl shadow-xl border border-gray-100 z-10 w-64">
                  <div className="grid grid-cols-8 gap-1">
                    {EMOJI_OPTIONS.map((emoji) => (
                      <button
                        key={emoji}
                        onClick={() => {
                          setFormData(prev => ({ ...prev, image: emoji }));
                          setShowEmojiPicker(false);
                        }}
                        className="w-8 h-8 flex items-center justify-center text-lg hover:bg-gray-100 rounded-lg"
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* 菜品名称 */}
          <div>
            <label className="text-sm text-[var(--soft-brown)] mb-2 block">菜品名称 *</label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
              placeholder="请输入菜品名称"
              className="input-sakura"
            />
          </div>

          {/* 价格 */}
          <div>
            <label className="text-sm text-[var(--soft-brown)] mb-2 block">价格 *</label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500">¥</span>
              <input
                type="number"
                value={formData.price || ''}
                onChange={(e) => setFormData(prev => ({ ...prev, price: Number(e.target.value) }))}
                placeholder="0.00"
                min="0"
                step="0.01"
                className="input-sakura pl-8"
              />
            </div>
          </div>

          {/* 分类 */}
          <div>
            <label className="text-sm text-[var(--soft-brown)] mb-2 block">分类</label>
            <div className="flex flex-wrap gap-2">
              {categories.filter(c => c.id !== 'all').map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setFormData(prev => ({ ...prev, category: cat.id }))}
                  className={`px-3 py-1.5 rounded-xl text-sm transition-all ${
                    formData.category === cat.id
                      ? 'bg-gradient-to-r from-[var(--sakura-pink)] to-[var(--sakura-light)] text-white'
                      : 'bg-gray-100 text-[var(--warm-brown)] hover:bg-gray-200'
                  }`}
                >
                  {cat.name}
                </button>
              ))}
            </div>
          </div>

          {/* 原材料 */}
          <div>
            <label className="text-sm text-[var(--soft-brown)] mb-2 block">原材料</label>
            <div className="flex gap-2 mb-2">
              <input
                type="text"
                value={newIngredient}
                onChange={(e) => setNewIngredient(e.target.value)}
                placeholder="添加原材料"
                className="input-sakura flex-1"
                onKeyDown={(e) => e.key === 'Enter' && addIngredient()}
              />
              <button
                onClick={addIngredient}
                className="px-4 py-2 rounded-xl bg-[var(--sakura-pink)] text-white hover:opacity-90"
              >
                <Plus className="w-5 h-5" />
              </button>
            </div>
            <div className="flex flex-wrap gap-1">
              {formData.ingredients?.map((ing) => (
                <span key={ing} className="tag-sakura flex items-center gap-1">
                  {ing}
                  <button
                    onClick={() => removeIngredient(ing)}
                    className="hover:text-red-500"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ))}
            </div>
          </div>

          {/* 口味选项 */}
          <div>
            <label className="text-sm text-[var(--soft-brown)] mb-2 block">口味选项</label>
            <div className="flex flex-wrap gap-2">
              {TASTE_OPTIONS.map((taste) => (
                <button
                  key={taste.id}
                  onClick={() => toggleTaste(taste.id)}
                  className={`px-3 py-1.5 rounded-xl text-sm transition-all ${
                    formData.tasteOptions?.includes(taste.id)
                      ? 'bg-gradient-to-r from-[var(--sakura-pink)] to-[var(--sakura-light)] text-white'
                      : 'bg-gray-100 text-[var(--warm-brown)] hover:bg-gray-200'
                  }`}
                >
                  {taste.name}
                </button>
              ))}
            </div>
          </div>

          {/* 描述 */}
          <div>
            <label className="text-sm text-[var(--soft-brown)] mb-2 block">描述</label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="请输入菜品描述"
              rows={3}
              className="input-sakura resize-none"
            />
          </div>

          {/* 上架状态 */}
          <div className="flex items-center justify-between">
            <span className="text-sm text-[var(--soft-brown)]">立即上架</span>
            <button
              onClick={() => setFormData(prev => ({ ...prev, isAvailable: !prev.isAvailable }))}
              className={`w-12 h-6 rounded-full transition-colors relative ${
                formData.isAvailable ? 'bg-[var(--sakura-pink)]' : 'bg-gray-300'
              }`}
            >
              <span
                className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-transform ${
                  formData.isAvailable ? 'left-7' : 'left-1'
                }`}
              />
            </button>
          </div>
        </div>

        {/* 底部按钮 */}
        <div className="sticky bottom-0 bg-white border-t border-gray-100 p-4 flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 py-3 rounded-2xl bg-gray-100 text-gray-600 font-medium hover:bg-gray-200 transition-colors"
          >
            取消
          </button>
          <button
            onClick={handleSave}
            disabled={!formData.name || !formData.price}
            className="flex-1 py-3 rounded-2xl bg-gradient-to-r from-[var(--sakura-pink)] to-[var(--sakura-light)] text-white font-medium hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {dish ? '保存修改' : '添加菜品'}
          </button>
        </div>
      </div>
    </div>
  );
}
