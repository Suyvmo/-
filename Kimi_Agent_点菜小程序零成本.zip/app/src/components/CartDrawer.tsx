import { useState, useMemo } from 'react';
import { Minus, Plus, Trash2, ShoppingBag, X } from 'lucide-react';
import type { CartItem, Taste } from '@/types';

interface CartDrawerProps {
  cart: CartItem[];
  total: number;
  onUpdateQuantity: (dishId: string, taste: Taste, remark: string, quantity: number) => void;
  onRemove: (dishId: string, taste: Taste, remark: string) => void;
  onSubmit: () => void;
  customerName?: string;
}

const TASTE_NAMES: Record<Taste, string> = {
  none: '不辣',
  mild: '微辣',
  medium: '中辣',
  spicy: '特辣',
};

export function CartDrawer({
  cart,
  total,
  onUpdateQuantity,
  onRemove,
  onSubmit,
}: CartDrawerProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  const itemCount = useMemo(() => {
    return cart.reduce((sum, item) => sum + item.quantity, 0);
  }, [cart]);

  const handleSubmit = () => {
    if (cart.length === 0) return;
    onSubmit();
    setIsExpanded(false);
  };

  if (cart.length === 0 && !isExpanded) {
    return (
      <div className="fixed bottom-20 left-4 right-4">
        <div className="bg-white rounded-2xl shadow-lg p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center">
              <ShoppingBag className="w-6 h-6 text-gray-400" />
            </div>
            <span className="text-gray-500">还没有点菜哦~</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      {/* 折叠状态 */}
      {!isExpanded && (
        <div className="fixed bottom-20 left-4 right-4 animate-fade-in-up">
          <div className="bg-white rounded-2xl shadow-lg p-4 flex items-center justify-between">
            <div 
              className="flex items-center gap-3 flex-1 cursor-pointer"
              onClick={() => setIsExpanded(true)}
            >
              <div className="w-12 h-12 rounded-full bg-gradient-to-r from-[var(--sakura-pink)] to-[var(--sakura-light)] flex items-center justify-center relative">
                <ShoppingBag className="w-6 h-6 text-white" />
                {itemCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center font-bold">
                    {itemCount}
                  </span>
                )}
              </div>
              <div>
                <span className="text-2xl font-bold text-[var(--sakura-pink)]">¥{total}</span>
                <span className="text-sm text-gray-500 ml-2">共{itemCount}件</span>
              </div>
            </div>
            
            <button
              onClick={handleSubmit}
              className="btn-sakura animate-pulse-soft"
            >
              提交订单
            </button>
          </div>
        </div>
      )}

      {/* 展开状态 */}
      {isExpanded && (
        <div 
          className="fixed inset-0 bg-black/30 z-40"
          onClick={() => setIsExpanded(false)}
        >
          <div 
            className="cart-drawer bottom-0 max-h-[70vh] z-50 flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            {/* 拖动条 */}
            <div 
              className="flex justify-center py-2 cursor-pointer"
              onClick={() => setIsExpanded(false)}
            >
              <div className="w-12 h-1.5 rounded-full bg-gray-300" />
            </div>

            {/* 头部 */}
            <div className="px-5 py-3 border-b border-gray-100 flex items-center justify-between">
              <h3 className="font-bold text-[var(--warm-brown)]">我的订单</h3>
              <button 
                onClick={() => setIsExpanded(false)}
                className="p-1 rounded-full hover:bg-gray-100"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            {/* 菜品列表 */}
            <div className="flex-1 overflow-auto p-4 space-y-3">
              {cart.map((item, index) => (
                <div 
                  key={`${item.dishId}-${item.taste}-${item.remark}`}
                  className="flex items-center gap-3 bg-gray-50 rounded-xl p-3 animate-fade-in-up"
                  style={{ animationDelay: `${index * 50}ms` }}
                >
                  {/* 菜品emoji */}
                  <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-pink-50 to-pink-100 flex items-center justify-center text-2xl flex-shrink-0">
                    {item.dish.image}
                  </div>

                  {/* 菜品信息 */}
                  <div className="flex-1 min-w-0">
                    <h4 className="font-bold text-[var(--warm-brown)] text-sm truncate">
                      {item.dish.name}
                    </h4>
                    <div className="flex items-center gap-1 text-xs text-gray-500 mt-0.5">
                      <span>{TASTE_NAMES[item.taste]}</span>
                      {item.remark && (
                        <span className="truncate max-w-[100px]">| {item.remark}</span>
                      )}
                    </div>
                    <span className="text-[var(--sakura-pink)] font-bold text-sm">
                      ¥{item.dish.price}
                    </span>
                  </div>

                  {/* 数量控制 */}
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onUpdateQuantity(item.dishId, item.taste, item.remark, item.quantity - 1)}
                      className="w-7 h-7 rounded-full bg-white border border-gray-200 flex items-center justify-center hover:border-[var(--sakura-pink)] transition-colors"
                    >
                      <Minus className="w-4 h-4 text-gray-600" />
                    </button>
                    <span className="w-6 text-center font-bold text-[var(--warm-brown)]">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => onUpdateQuantity(item.dishId, item.taste, item.remark, item.quantity + 1)}
                      className="w-7 h-7 rounded-full bg-white border border-gray-200 flex items-center justify-center hover:border-[var(--sakura-pink)] transition-colors"
                    >
                      <Plus className="w-4 h-4 text-gray-600" />
                    </button>
                  </div>

                  {/* 删除按钮 */}
                  <button
                    onClick={() => onRemove(item.dishId, item.taste, item.remark)}
                    className="p-2 rounded-full hover:bg-red-50 transition-colors"
                  >
                    <Trash2 className="w-4 h-4 text-red-400" />
                  </button>
                </div>
              ))}
            </div>

            {/* 底部结算 */}
            <div className="p-4 border-t border-gray-100 bg-white">
              <div className="flex items-center justify-between mb-3">
                <span className="text-gray-600">共 {itemCount} 件商品</span>
                <div className="text-right">
                  <span className="text-sm text-gray-500">合计：</span>
                  <span className="text-2xl font-bold text-[var(--sakura-pink)]">¥{total}</span>
                </div>
              </div>
              <button
                onClick={handleSubmit}
                className="btn-sakura w-full py-4 text-lg"
              >
                确认下单
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
