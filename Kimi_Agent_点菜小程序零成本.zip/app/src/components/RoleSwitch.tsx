import { ChefHat, User } from 'lucide-react';
import type { UserRole } from '@/types';

interface RoleSwitchProps {
  currentRole: UserRole;
  onSwitch: () => void;
}

export function RoleSwitch({ currentRole, onSwitch }: RoleSwitchProps) {
  return (
    <div className="px-4 py-3">
      <div className="role-switch">
        <button
          onClick={() => currentRole === 'chef' && onSwitch()}
          className={`role-option flex items-center justify-center gap-2 ${
            currentRole === 'customer' ? 'active' : ''
          }`}
        >
          <User className="w-4 h-4" />
          <span>我是食客</span>
        </button>
        <button
          onClick={() => currentRole === 'customer' && onSwitch()}
          className={`role-option flex items-center justify-center gap-2 ${
            currentRole === 'chef' ? 'active' : ''
          }`}
        >
          <ChefHat className="w-4 h-4" />
          <span>我是厨师</span>
        </button>
      </div>
    </div>
  );
}
