import { useState } from 'react';
import { Plus, Minus, Edit2, Trash2 } from 'lucide-react';
import type { Dish, Taste } from '@/types';

interface DishCardProps {
  dish: Dish;
  isChef: boolean;
  onAddToCart?: (dish: Dish, taste: Taste, remark: string, quantity: number) => void;
  onEdit?: (dish: Dish) => void;
  onDelete?: (dishId: string) => void;
  index?: number;
}

const TASTE_OPTIONS = [
  { id: 'none' as Taste, name: '不辣' },
  { id: 'mild' as Taste, name: '微辣' },
  { id: 'medium' as Taste, name: '中辣' },
  { id: 'spicy' as Taste, name: '特辣' },
];

export function DishCard({ dish, isChef, onAddToCart, onEdit, onDelete, index = 0 }: DishCardProps) {
  const [showDetail, setShowDetail] = useState(false);
  const [selectedTaste, setSelectedTaste] = useState<Taste>(dish.tasteOptions[0] || 'none');
  const [remark, setRemark] = useState('');
  const [quantity, setQuantity] = useState(1);

  const handleAddToCart = () => {
    if (onAddToCart) {
      onAddToCart(dish, selectedTaste, remark, quantity);
      setShowDetail(false);
      setQuantity(1);
      setRemark('');
    }
  };

  const animationDelay = `${index * 50}ms`;

  if (!dish.isAvailable && !isChef) return null;

  return (
    <>
      <div
        className={`dish-card relative ${!dish.isAvailable ? 'opacity-50' : ''}`}
        style={{ animationDelay }}
      >
        {/* 菜品图片/emoji */}
        <div 
          className="aspect-square flex items-center justify-center text-6xl bg-gradient-to-br from-pink-50 to-pink-100 cursor-pointer"
          onClick={() => !isChef && setShowDetail(true)}
        >
          {dish.image}
        </div>

        {/* 菜品信息 */}
        <div className="p-3">
          <div className="flex items-start justify-between mb-1">
            <h3 className="font-bold text-[var(--warm-brown)] text-sm line-clamp-1 flex-1">
              {dish.name}
            </h3>
            {!dish.isAvailable && (
              <span className="tag-sakura text-xs ml-1">已下架</span>
            )}
          </div>
          
          <p className="text-xs text-[var(--soft-brown)] mb-2 line-clamp-1">
            {dish.ingredients.join('、')}
          </p>
          
          <div className="flex items-center justify-between">
            <span className="text-lg font-bold text-[var(--sakura-pink)]">
              ¥{dish.price}
            </span>
            
            {isChef ? (
              <div className="flex gap-1">
                <button
                  onClick={() => onEdit?.(dish)}
                  className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center hover:bg-gray-200 transition-colors"
                >
                  <Edit2 className="w-4 h-4 text-gray-600" />
                </button>
                <button
                  onClick={() => onDelete?.(dish.id)}
                  className="w-8 h-8 rounded-full bg-red-100 flex items-center justify-center hover:bg-red-200 transition-colors"
                >
                  <Trash2 className="w-4 h-4 text-red-500" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => setShowDetail(true)}
                className="w-8 h-8 rounded-full bg-gradient-to-r from-[var(--sakura-pink)] to-[var(--sakura-light)] flex items-center justify-center hover:scale-110 transition-transform"
              >
                <Plus className="w-5 h-5 text-white" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* 详情弹窗 */}
      {showDetail && (
        <div 
          className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
          onClick={() => setShowDetail(false)}
        >
          <div 
            className="bg-white rounded-3xl w-full max-w-sm overflow-hidden animate-fade-in-up"
            onClick={(e) => e.stopPropagation()}
          >
            {/* 菜品大图 */}
            <div className="aspect-video flex items-center justify-center text-8xl bg-gradient-to-br from-pink-50 to-pink-100">
              {dish.image}
            </div>

            <div className="p-5">
              {/* 名称和价格 */}
              <div className="flex items-center justify-between mb-2">
                <h2 className="text-xl font-bold text-[var(--warm-brown)]">{dish.name}</h2>
                <span className="text-2xl font-bold text-[var(--sakura-pink)]">¥{dish.price}</span>
              </div>

              {/* 描述 */}
              {dish.description && (
                <p className="text-sm text-[var(--soft-brown)] mb-3">{dish.description}</p>
              )}

              {/* 原材料 */}
              <div className="mb-4">
                <span className="text-xs text-[var(--soft-brown)] mb-1 block">原材料</span>
                <div className="flex flex-wrap gap-1">
                  {dish.ingredients.map((ing, i) => (
                    <span key={i} className="tag-sakura text-xs">{ing}</span>
                  ))}
                </div>
              </div>

              {/* 口味选择 */}
              {dish.tasteOptions.length > 0 && (
                <div className="mb-4">
                  <span className="text-xs text-[var(--soft-brown)] mb-2 block">口味选择</span>
                  <div className="flex flex-wrap gap-2">
                    {TASTE_OPTIONS.filter(t => dish.tasteOptions.includes(t.id)).map((taste) => (
                      <button
                        key={taste.id}
                        onClick={() => setSelectedTaste(taste.id)}
                        className={`px-3 py-1.5 rounded-xl text-sm transition-all ${
                          selectedTaste === taste.id
                            ? 'bg-gradient-to-r from-[var(--sakura-pink)] to-[var(--sakura-light)] text-white'
                            : 'bg-gray-100 text-[var(--warm-brown)] hover:bg-gray-200'
                        }`}
                      >
                        {taste.name}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* 备注 */}
              <div className="mb-4">
                <span className="text-xs text-[var(--soft-brown)] mb-1 block">备注</span>
                <input
                  type="text"
                  value={remark}
                  onChange={(e) => setRemark(e.target.value)}
                  placeholder="请输入口味偏好或其他要求..."
                  className="input-sakura text-sm"
                />
              </div>

              {/* 数量选择和加入购物车 */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="quantity-btn"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="text-lg font-bold text-[var(--warm-brown)] w-8 text-center">
                    {quantity}
                  </span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="quantity-btn"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>

                <button
                  onClick={handleAddToCart}
                  className="btn-sakura flex items-center gap-2"
                >
                  <span>加入购物车</span>
                  <span className="font-bold">¥{dish.price * quantity}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
